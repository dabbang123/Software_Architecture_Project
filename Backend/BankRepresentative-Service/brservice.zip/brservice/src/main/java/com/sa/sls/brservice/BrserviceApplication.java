package com.sa.sls.brservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrserviceApplication.class, args);
	}

}
