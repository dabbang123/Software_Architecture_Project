package com.sa.sls.brservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
