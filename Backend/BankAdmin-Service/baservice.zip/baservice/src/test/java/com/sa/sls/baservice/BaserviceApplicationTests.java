package com.sa.sls.baservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
